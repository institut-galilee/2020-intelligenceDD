secure-smtplib
==============

Secure SMTP subclasses for Python 2

Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/dht_simpletest.py
    :caption: examples/dht_simpletest.py
    :linenos:

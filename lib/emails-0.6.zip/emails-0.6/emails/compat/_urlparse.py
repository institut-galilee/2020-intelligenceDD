# encoding: utf-8

try:
    from urlparse import *
except ImportError:
    from urllib.parse import *

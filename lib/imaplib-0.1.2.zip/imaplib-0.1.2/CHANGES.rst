Changes
=========

0.1.0 (2015-04-07)
------------------

- First version of secure-imaplib that can be installed from PyPI

secure-imaplib
==============

Secure IMAP subclasses for Python 2

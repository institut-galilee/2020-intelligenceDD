.. automodule:: neopixel
   :members:

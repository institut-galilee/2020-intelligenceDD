Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/neopixel_simpletest.py
    :caption: examples/neopixel_simpletest.py
    :linenos:

.. literalinclude:: ../examples/neopixel_rpi_simpletest.py
    :caption: examples/neopixel_rpi_simpletest.py
    :linenos:
